#include <vector>
#include <iostream>
#include "Tuple.h"
#include "Scheme.h"
#include "Relation.h"
#include "Interpreter.h"
#include "Scanner.h"

using namespace std;

int main(int argc, char* argv[]) {
  
  string filename = argv[1];
  ifstream inputFile(filename);
  if (!inputFile) {
      cerr << "Error: Unable to open file!" << endl;
      return 1;
  }
  string file_content((istreambuf_iterator<char>(inputFile)), istreambuf_iterator<char>());
  Scanner s = Scanner(file_content);
  vector<Token> token_list = s.scanTokens();
  inputFile.close();
  Parser p = Parser(token_list);
  DatalogProgram DP = p.parse();
  Interpreter I = Interpreter(DP);
  I.interpret();

  // Relation studentRelation("students", Scheme( {"ID", "Name", "Major"} ));
  // Relation courseRelation("courses", Scheme( {"ID", "Course"} ));

  // vector<string> studentValues[] = {
  //   {"'42'", "'Ann'", "'CS'"},
  //   {"'64'", "'Ned'", "'EE'"},
  // };

  // vector<string> courseValues[] = {
  //   {"'42'", "'CS 100'"},
  //   {"'10'", "'CS 232'"},
  // };

  // for (auto& value : studentValues)
  //   studentRelation.addTuple(Tuple(value));

  // for (auto& value : courseValues)
  //   courseRelation.addTuple(Tuple(value));

  // Scheme Scheme1 = Scheme( {"ID", "Name", "Major"} );
  // Scheme Scheme2 = Scheme( {"Course", "random", "ID"} );

  // Relation newRelation = studentRelation.join(courseRelation);
  // cout << newRelation.toString() << endl;
}
