#pragma once
#include <set>
#include <sstream>

using namespace std;

class Node {

 private:

  set<int> adjacentNodeIDs;

 public:

  void addEdge(int adjacentNodeID) {
    adjacentNodeIDs.insert(adjacentNodeID);
  }

  string toString() {
    stringstream out;
    for (int edge : adjacentNodeIDs) {
        out << "R" << edge << ",";
    }
    string result = out.str();
    if (!result.empty()) {
        result.pop_back();
    }
    return result;
  }

};
